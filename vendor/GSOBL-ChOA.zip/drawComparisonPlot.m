function [] = drawComparisonPlot(function_name, curve_list, curve_name_list, curve_color_list)

figure('Position',[500 500 660 290])
% Draw search space
subplot(1,2,1);
func_plot(num2str(cell2mat(function_name)));
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([num2str(cell2mat(function_name)),'( x_1 , x_2 )'])

%Draw objective space
subplot(1,2,2);
for loop = 1:size(curve_list,1)
    semilogy(curve_list(:,loop),'Color',curve_color_list(1,loop));
    hold on;
end
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');

axis tight
grid on
box on
legend(curve_name_list)  % chnage this according to your required names
end
