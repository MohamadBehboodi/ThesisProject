# MATLAB code for Evolving Chimp Optimization Algorithm by Weighted Opposition-Based Technique and Greedy Search for Multimodal Engineering Problems

Code to perform function optimization.

### This is code for paper entitled - Evolving Chimp Optimization Algorithm by Weighted Opposition-Based Technique and Greedy Search for Multimodal Engineering Problems

## Parameters

The following parameters must be set in main.m file for running the code
* iteration - the number of runs per function
* SearchAgents_no - population size
* Max_iteration - iterations of each function to be executed
* algo_choice - which algorithm to run


## Running the code
* Set all the required parameters in the files specified above
* you can run file main_GSOBLChOA & main_GSOBLChOA2
