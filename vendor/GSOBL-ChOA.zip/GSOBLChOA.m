% Evolving Chimp Optimization Algorithm by Opposition-Based Technique and Greedy Search for Multimodal Engineering Problems source codes version 1.0   
% By: Qiuyu Bo, Wuqun Cheng, Mohammad Khishe
% m_khishe@alumni.iust.ac.ir

% Please note that some files and functions are taken from the Chimp Optimization Algorithm          %
%%
function [Attacker_score,Attacker_pos,Convergence_curve]=GSOBLChOA(SearchAgents_no,Max_iter,lb,ub,dim,fobj)

% initialize Attacker, Barrier, and Driver_pos
Attacker_pos=zeros(1,dim);
Attacker_score=inf; %change this to -inf for maximization problems

Barrier_pos=zeros(1,dim);
Barrier_score=inf; %change this to -inf for maximization problems

Chaser_pos=zeros(1,dim);
Chaser_score=inf; %change this to -inf for maximization problems


Driver_pos=zeros(1,dim);
Driver_score=inf; %change this to -inf for maximization problems

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%initializing boundary for opposition
Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    for i=1:dim
        upper(1,i)=ub;
        lower(1,i)=lb;
    end
    % If each variable has a different lb and ub
else
    for i=1:dim
        upper(1,i)=ub(i);
        lower(1,i)=lb(i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initialize the positions of search agents
Positions=initialization(SearchAgents_no,dim,ub,lb);

Convergence_curve=zeros(1,Max_iter);

l=0;% Loop counter

fitness=zeros(size(Positions(:,1)));
% Main loop
while l<Max_iter
    for i=1:size(Positions,1)
        
        % Return back the search agents that go beyond the boundaries of the search space
        Flag4ub=Positions(i,:)>ub;
        Flag4lb=Positions(i,:)<lb;
        Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        % Calculate objective function for each search agent
        fitness(i)=fobj(Positions(i,:));
        
        % Update Attacker, Barrier, and Driver
        if fitness(i)<Attacker_score
            Attacker_score=fitness(i); % Update Attacker
            Attacker_pos=Positions(i,:);
        end
        
        if fitness(i)>Attacker_score && fitness(i)<Barrier_score
            Barrier_score=fitness(i); % Update Barrier
            Barrier_pos=Positions(i,:);
        end
        
        if fitness(i)>Attacker_score && fitness(i)>Barrier_score && fitness(i)<Driver_score
            Driver_score=fitness(i); % Update Driver
            Driver_pos=Positions(i,:);
        end
         if fitness(i)>Attacker_score && fitness(i)>Barrier_score && fitness(i)>Driver_score && fitness(i)<Chaser_score
            Chaser_score=fitness(i); % Update Driver
            Chaser_pos=Positions(i,:);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %updating boundary for opposition after every iteration
        for x=1:size(Positions,1)
            for y=1:size(Positions,2)
                if upper(1,y)<Positions(x,y)
                    upper(1,y)=Positions(x,y);
                end
                if lower(1,y)>Positions(x,y)
                    lower(1,y)=Positions(x,y);
                end
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end
    
    
    f=2-l*((2)/Max_iter); % a decreases linearly fron 2 to 0
    C1G1=1.95-((2*l^(1/3))/(Max_iter^(1/3)));
    C2G1=(2*l^(1/3))/(Max_iter^(1/3))+0.5;
        
    %Group 2
    C1G2= 1.95-((2*l^(1/3))/(Max_iter^(1/3)));
    C2G2=(2*(l^3)/(Max_iter^3))+0.5;
    
    %Group 3
    C1G3=(-2*(l^3)/(Max_iter^3))+2.5;
    C2G3=(2*l^(1/3))/(Max_iter^(1/3))+0.5;
    
    %Group 4
    C1G4=(-2*(l^3)/(Max_iter^3))+2.5;
    C2G4=(2*(l^3)/(Max_iter^3))+0.5;
    
    % Oppose the least fitness elements
    threshold=f;
    Positions=corOppose(Positions,fitness,ub,lb,upper,lower,dim,threshold);
    
    % Update the Position of search agents including omegas
    for i=1:size(Positions,1)
        for j=1:size(Positions,2)
            
          %% Please note that to choose a other groups you should use the related group strategies
            r11=C1G1*rand(); 
            r12=C2G1*rand(); 
            
            r21=C1G2*rand(); 
            r22=C2G2*rand(); 
            
            r31=C1G3*rand(); 
            r32=C2G3*rand(); 
            
            r41=C1G4*rand(); 
            r42=C2G4*rand(); 
            
            A1=2*f*r11-f; 
            C1=2*r12; 
           
%% % Please note that to choose various Chaotic maps you should use the related Chaotic maps strategies
            m=chaos(3,1,1); 
            D_Attacker=abs(C1*Attacker_pos(j)-m*Positions(i,j)); % Equation (5)
            X1=Attacker_pos(j)-A1*D_Attacker; 
                       
            A2=2*f*r21-f; 
            C2=2*r22; 
            
                   
            D_Barrier=abs(C2*Barrier_pos(j)-m*Positions(i,j)); 
            X2=Barrier_pos(j)-A2*D_Barrier;   
            
        
            
            A3=2*f*r31-f; 
            C3=2*r32; 
            
            D_Driver=abs(C3*Chaser_pos(j)-m*Positions(i,j)); 
            X3=Chaser_pos(j)-A3*D_Driver;  
            
            A4=2*f*r41-f; 
            C4=2*r42;  
            
            D_Driver=abs(C4*Driver_pos(j)-m*Positions(i,j)); 
            X4=Chaser_pos(j)-A4*D_Driver; 
            
            W1=abs(X1)/(abs(X1)+abs(X2)+abs(X3)+abs(X4));
            W2=abs(X1)/(abs(X2)+abs(X2)+abs(X3)+abs(X4));
            W3=abs(X1)/(abs(X3)+abs(X2)+abs(X3)+abs(X4));
            W4=abs(X1)/(abs(X4)+abs(X2)+abs(X3)+abs(X4));
            
            
%             
            Positions(i,j)=1./(W1+W2+W3+W4).*(W1.*X1+W2.*X2+W3.*X3+W4.*X4)/4;
            
%            
            
        end
    end
    l=l+1;
    Convergence_curve(l)=Attacker_score;
end
end



